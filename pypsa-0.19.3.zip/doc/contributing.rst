#######################
Contributing
#######################


We strongly welcome anyone interested in contributing to this project.

Submit pull requests / issues to the `github repository <https://github.com/PyPSA/PyPSA>`_.

Join the `mailing list
<https://groups.google.com/group/pypsa>`_.

See the list of :doc:`developers`.
