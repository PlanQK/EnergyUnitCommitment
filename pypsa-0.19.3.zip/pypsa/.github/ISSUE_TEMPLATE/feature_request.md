---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: enhancement
assignees: ''

---

<!-- Please do not post usage questions here. Ask them on the PyPSA mailing list: https://groups.google.com/forum/#!forum/pypsa -->

## Describe the feature you'd like to see

*Please give a clear and concise description and provide context why the feature would be useful.*
*Also, we'd appreciate any implementation ideas and references you already have.*
