#######################
Mailing List
#######################



PyPSA has a Google Group `forum / mailing list
<https://groups.google.com/group/pypsa>`_.

Anyone can join and anyone can read the posts; only members of the
group can post to the list.

The intention is to have a place where announcements of new releases
can be made and questions can be asked.

Please ask questions on the mailing list rather than emailing the
developers directly, so that others can also profit from the answers.

To discuss issues and suggest/contribute features
for future development we prefer ticketing through the `PyPSA Github Issues page
<https://github.com/PyPSA/PyPSA/issues>`_.
