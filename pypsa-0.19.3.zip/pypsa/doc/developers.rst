####################
Developers of PyPSA
####################


The following people have `contributed
<https://github.com/PyPSA/PyPSA/graphs/contributors>`_ significantly
towards the development of PyPSA:

* 2015-2021 Tom Brown (FIAS, KIT, TUB)
* 2015-2021 Jonas Hörsch (FIAS, KIT)
* 2019-2021 Fabian Hofmann (FIAS)
* 2018-2021 Fabian Neumann (KIT)
* 2020-2021 Lisa Zeyen (KIT)
* 2017-2018 Chloe Syranidis (FZJ)
* 2020-2021 Martha Frysztacki (KIT)
* 2016 David Schlachberger (KIT)
